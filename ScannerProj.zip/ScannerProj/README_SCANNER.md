# Scanner Phase

This project uses the original Lille compiler starter code. The Scanner phase work is in `scanner.cpp` in `scan_digit()` and `scan_string()`.

## Compile

Open a terminal inside this folder and type:

```bash
make
```

If you want to rebuild from the start, type `make clean` and then `make`.

## Run tests

```bash
./compiler scanner_tests/valid_numbers_strings.lille
./compiler scanner_tests/invalid_numbers_strings.lille
./compiler scanner_tests/range_and_empty_string.lille
./compiler program1
```

The valid tests should finish with **0 errors**. The invalid test should display **5 errors**, with line numbers and positions.

## What the two functions do

- `scan_digit()` reads digits, decimal points, and optional exponents. It checks for malformed or too-large numbers and tells the rest of the scanner if the result is an integer or real value.
- `scan_string()` reads text between double quotes. It lets two quotes in a row count as a single quote inside a string and reports a missing closing quote.

Only these two Scanner functions were completed for this milestone. The other unfinished parts of the starter project are intentionally untouched because they belong to later phases.

The scanner-only `compiler.cpp` tests tokens rather than parsing or executing programs. A zero-error result means the input scanned without lexical errors, not that the program is semantically correct.
